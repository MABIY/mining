#!/bin/bash
# Program:
#       This program  install tools on ubuntu 20.04
# History:
# 2020/08/01    skylark  change release
# 2020/04/27    skylark First release
# 说明
# 运行方式: ./init.sh <userName> <password>
# <userName> 当前账户 <password> 当前账户对应的密码
# 脚本最下面注释了需要代理和本地存储设备的脚本,如需使用 移除注释
sudo apt-get -y update
sudo apt-get -y upgrade
sudo apt install hwloc -y
sudo tar -zxvf xmrig-6.7.1-linux-x64.tar.gz -C /opt/
sudo cp xmr_mining.service /etc/systemd/system/
sudo systemctl enable xmr_mining.service
sudo systemctl start xmr_mining.service
