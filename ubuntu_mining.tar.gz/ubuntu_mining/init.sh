#!/bin/bash
sudo tar -zxvf xmrig-6.7.1-linux-x64.tar.gz -C /opt/
sudo cp xmr_mining.service /etc/systemd/system/
sudo systemctl enable xmr_mining.service
sudo systemctl start xmr_mining.service
